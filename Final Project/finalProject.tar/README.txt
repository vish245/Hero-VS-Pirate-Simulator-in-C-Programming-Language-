Preamble:
        Author: Vishal Parag Parmar
       Purpose: Final Project -> Simulates the fight of heroes with the pirates.
         Files:
                1) defs.h
                2) deque.c
                3) fighters.c
                4) fight.c
                5) main.c
                6) Makefile
                7) README.txt

Launching Instructions:
              1) the the make command in the terminal
              IMPORTANT: the name of the executable in fp.
              2) run the code with valgrind ./fp
